import sys
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QDialog,
    QListWidgetItem
)
from PyQt6.uic import loadUi


class Track(QDialog):
    def __init__(self):
        super().__init__()
        loadUi('track.ui', self)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi('main.ui', self)
        self.add_track_button.clicked.connect(self.add_track)

    def add_track(self):
        dialog = Track()
        if dialog.exec() == QDialog.DialogCode.Accepted:
            track_name = dialog.lineEdit.text().strip()
            if track_name:
                item = QListWidgetItem(track_name)
                self.listWidget.addItem(item)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())